package software.bernie.geckolib.network.packet.entity;

import org.jspecify.annotations.Nullable;
import software.bernie.geckolib.GeckoLibConstants;
import software.bernie.geckolib.animatable.GeoEntity;
import software.bernie.geckolib.animatable.GeoReplacedEntity;
import software.bernie.geckolib.network.packet.MultiloaderPacket;
import software.bernie.geckolib.util.ClientUtil;
import software.bernie.geckolib.util.RenderUtil;

import java.util.Optional;
import java.util.function.Consumer;
import net.minecraft.entity.Entity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.network.PacketByteBuf;
import net.minecraft.network.codec.PacketCodec;
import net.minecraft.network.codec.PacketCodecs;
import net.minecraft.network.packet.CustomPayload;
import net.minecraft.world.World;

public record StopTriggeredEntityAnimPacket(int entityId, boolean isReplacedEntity, Optional<String> controllerName, Optional<String> animName) implements MultiloaderPacket {
    public static final Id<StopTriggeredEntityAnimPacket> TYPE = new Id<>(GeckoLibConstants.id("stop_triggered_entity_anim"));
    public static final PacketCodec<PacketByteBuf, StopTriggeredEntityAnimPacket> CODEC = PacketCodec.tuple(
            PacketCodecs.VAR_INT, StopTriggeredEntityAnimPacket::entityId,
            PacketCodecs.BOOLEAN, StopTriggeredEntityAnimPacket::isReplacedEntity,
            PacketCodecs.STRING.collect(PacketCodecs::optional), StopTriggeredEntityAnimPacket::controllerName,
            PacketCodecs.STRING.collect(PacketCodecs::optional), StopTriggeredEntityAnimPacket::animName,
            StopTriggeredEntityAnimPacket::new);

    @Override
    public Id<? extends CustomPayload> getId() {
        return TYPE;
    }

    @Override
    public void receiveMessage(@Nullable PlayerEntity sender, Consumer<Runnable> workQueue) {
        workQueue.accept(() -> {
            final World level = ClientUtil.getLevel();
            final Entity entity;

            if (level == null || (entity = level.getEntityById(this.entityId)) == null)
                return;

            if (!this.isReplacedEntity) {
                if (entity instanceof GeoEntity geoEntity)
                    geoEntity.stopTriggeredAnim(this.controllerName.orElse(null), this.animName.orElse(null));

                return;
            }

            if (RenderUtil.getReplacedAnimatable(entity.getType()) instanceof GeoReplacedEntity replacedEntity)
                replacedEntity.stopTriggeredAnim(entity, this.controllerName.orElse(null), this.animName.orElse(null));
        });
    }
}
