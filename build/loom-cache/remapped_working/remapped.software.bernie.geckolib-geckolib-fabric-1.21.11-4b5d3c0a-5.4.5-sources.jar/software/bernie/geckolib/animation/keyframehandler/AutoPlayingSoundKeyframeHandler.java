package software.bernie.geckolib.animation.keyframehandler;

import net.minecraft.block.entity.BlockEntity;
import net.minecraft.client.render.entity.state.EntityRenderState;
import net.minecraft.entity.mob.Monster;
import net.minecraft.registry.Registries;
import net.minecraft.sound.SoundCategory;
import net.minecraft.util.Identifier;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.World;
import software.bernie.geckolib.GeckoLibConstants;
import software.bernie.geckolib.animatable.GeoAnimatable;
import software.bernie.geckolib.animation.AnimationController;
import software.bernie.geckolib.animation.state.KeyFrameEvent;
import software.bernie.geckolib.cache.animation.keyframeevent.SoundKeyframeData;
import software.bernie.geckolib.constant.DataTickets;
import software.bernie.geckolib.util.ClientUtil;

/**
 * Built-in helper for a {@link AnimationController.KeyframeEventHandler SoundKeyframeHandler} that automatically plays the sound defined in the keyframe data
 * <p>
 * Due to an inability to determine the position of the sound for all animatables, this handler only supports {@link software.bernie.geckolib.animatable.GeoEntity GeoEntity} and {@link software.bernie.geckolib.animatable.GeoBlockEntity GeoBlockEntity}
 * <p>
 * The expected keyframe data format is one of the below:
 * <pre>{@code
 * namespace:soundid
 * namespace:soundid|volume|pitch
 * }</pre>
 *
 * @param <A> Animatable class type
 */
public class AutoPlayingSoundKeyframeHandler<A extends GeoAnimatable> implements AnimationController.KeyframeEventHandler<A, SoundKeyframeData> {
    @Override
    public void handle(KeyFrameEvent<A, SoundKeyframeData> event) {
        final World level = ClientUtil.getLevel();

        if (level == null)
            return;

        String[] segments = event.keyframeData().getSound().split("\\|");

        Registries.SOUND_EVENT.getEntry(Identifier.validate(segments[0]).getOrThrow()).ifPresent(sound -> {
            Vec3d position = event.renderState().getOrDefaultGeckolibData(DataTickets.POSITION, event.renderState() instanceof EntityRenderState entityState ?
                                                                                          new Vec3d(entityState.x, entityState.y, entityState.z) : null);
            Class<?> animatableClass = event.renderState().getOrDefaultGeckolibData(DataTickets.ANIMATABLE_CLASS, Object.class);

            if (position != null) {
                float volume = segments.length > 1 ? Float.parseFloat(segments[1]) : 1;
                float pitch = segments.length > 2 ? Float.parseFloat(segments[2]) : 1;
                SoundCategory source = animatableClass.isAssignableFrom(BlockEntity.class) ? SoundCategory.BLOCKS :
                                     animatableClass.isAssignableFrom(Monster.class) ? SoundCategory.HOSTILE : SoundCategory.NEUTRAL;

                level.playSoundClient(position.x, position.y, position.z, sound.value(), source, volume, pitch, false);
            }
            else {
                GeckoLibConstants.LOGGER.warn("Found sound keyframe handler, but AnimationState had no position data for animatable: {}", animatableClass.getName());
            }
        });
    }
}
