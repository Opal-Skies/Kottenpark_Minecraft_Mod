package software.bernie.geckolib.cache;

import com.mojang.serialization.Codec;
import com.mojang.serialization.codecs.RecordCodecBuilder;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.world.PersistentState;
import net.minecraft.world.PersistentStateType;
import software.bernie.geckolib.GeckoLibConstants;
import software.bernie.geckolib.animatable.instance.SingletonAnimatableInstanceCache;

/**
 * Storage class that keeps track of the last animatable id used, and provides new ones on request
 * <p>
 * Generally only used for {@link net.minecraft.item.Item Items}, but any {@link SingletonAnimatableInstanceCache singleton} will likely use this.
 */
public final class AnimatableIdCache extends PersistentState {
	private static final Codec<AnimatableIdCache> CODEC = RecordCodecBuilder.create(builder -> builder.group(
			Codec.LONG.fieldOf("last_id").forGetter(cache -> cache.lastId)
	).apply(builder, AnimatableIdCache::new));
	@SuppressWarnings("DataFlowIssue")
    public static final PersistentStateType<AnimatableIdCache> TYPE = new PersistentStateType<>(GeckoLibConstants.MODID + "_id_cache", AnimatableIdCache::new, CODEC, null);

	private long lastId;

	private AnimatableIdCache() {
		this(0);
	}

	private AnimatableIdCache(long lastId) {
		this.lastId = lastId;
	}

	/**
	 * Get the next free id from the id cache
	 *
	 * @param level An arbitrary ServerLevel. It doesn't matter which one
	 * @return The next free ID, which is immediately reserved for use after calling this method
	 */
	public static long getFreeId(ServerWorld level) {
		return getCache(level.getServer().getOverworld()).getNextId();
	}

	private long getNextId() {
		markDirty();

		return ++this.lastId;
	}

	private static AnimatableIdCache getCache(ServerWorld level) {
		return level.getServer().getOverworld().getPersistentStateManager().getOrCreate(TYPE);
	}
}
