package software.bernie.geckolib.loading.definition.geometry;

import com.google.gson.*;
import org.jetbrains.annotations.ApiStatus;
import org.jspecify.annotations.Nullable;
import software.bernie.geckolib.util.JsonUtil;

import java.util.Map;
import net.minecraft.util.JsonHelper;
import net.minecraft.util.math.Vec3d;

/**
 * Container class for a single geometry bone, only used for intermediary steps between .json deserialization and GeckoLib object creation
 *
 * @param name The name of this bone
 * @param parent The parent bone of this bone, if any
 * @param pivot The pivot point for this bone, or null if not defined
 * @param rotation The rotation of this bone, in degrees, or null if not defined
 * @param debug An optional debug marker for this bone. Not used by GeckoLib
 * @param mirror An optional mirror toggle for this bone
 * @param inflate An optional inflation value for this bone
 * @param renderGroupId The numerical group index this bone belongs to. Not used by GeckoLib
 * @param cubes The array of cube definitions for this bone
 * @param binding An optional binding for this bone, defining its parental relationship. Not used by GeckoLib
 * @param locators An optional map of locator markers for this bone
 * @param polyMesh An optional poly mesh definition for this bone. Not used by GeckoLib
 * @param textureMeshes An optional array of texture mesh definitions for this bone. Not used by GeckoLib
 * @see <a href="https://learn.microsoft.com/en-us/minecraft/creator/reference/content/schemasreference/schemas/minecraftschema_geometry_1.21.0?view=minecraft-bedrock-experimental">Bedrock Geometry Spec 1.21.0</a>
 */
@ApiStatus.Internal
public record GeometryBone(String name, @Nullable String parent, @Nullable Vec3d pivot, @Nullable Vec3d rotation, boolean debug,
                           boolean mirror, float inflate, int renderGroupId, GeometryCube @Nullable [] cubes,
                           @Nullable String binding, @Nullable Map<String, GeometryLocator> locators, @Nullable GeometryPolyMesh polyMesh,
                           GeometryTextureMesh @Nullable[] textureMeshes) {
    /**
     * Parse a GeometryBone instance from raw .json input via {@link Gson}
     */
    public static JsonDeserializer<GeometryBone> gsonDeserializer() throws JsonParseException {
        return (json, type, context) -> {
            final JsonObject obj = json.getAsJsonObject();
            final String name = JsonHelper.getString(obj, "name");
            final String parent = JsonHelper.getString(obj, "parent", null);
            final Vec3d pivot = JsonUtil.jsonToVec3(JsonHelper.getArray(obj, "pivot", null));
            final Vec3d rotation = JsonUtil.jsonToVec3(JsonHelper.getArray(obj, "rotation", null));
            final boolean debug = JsonHelper.getBoolean(obj, "debug", false);
            final boolean mirror = JsonHelper.getBoolean(obj, "mirror", false);
            final float inflate = JsonHelper.getFloat(obj, "inflate", 0f);
            final int renderGroupId = JsonHelper.getInt(obj, "render_group_id", 0);
            final GeometryCube[] cubes = JsonUtil.jsonArrayToObjectArray(JsonHelper.getArray(obj, "cubes", new JsonArray()), context, GeometryCube.class);
            final String binding = JsonHelper.getString(obj, "binding", null);
            final Map<String, GeometryLocator> locators = JsonUtil.jsonObjToMap(JsonHelper.getObject(obj, "locators", null), context, GeometryLocator.class);
            final GeometryPolyMesh polyMesh = JsonHelper.deserialize(obj, "poly_mesh", null, context, GeometryPolyMesh.class);
            final GeometryTextureMesh[] textureMeshes = JsonUtil.jsonArrayToObjectArray(JsonHelper.getArray(obj, "texture_meshes", null), context, GeometryTextureMesh.class);

            return new GeometryBone(name, parent, pivot, rotation, debug, mirror, inflate, renderGroupId, cubes, binding, locators, polyMesh, textureMeshes);
        };
    }
}
