package software.bernie.geckolib.renderer.internal;

import com.mojang.serialization.MapCodec;
import org.jetbrains.annotations.ApiStatus;
import org.jspecify.annotations.Nullable;
import org.joml.Vector3f;
import org.joml.Vector3fc;
import software.bernie.geckolib.animatable.GeoAnimatable;
import software.bernie.geckolib.animatable.client.GeoRenderProvider;
import software.bernie.geckolib.constant.DataTickets;
import software.bernie.geckolib.renderer.GeoItemRenderer;
import software.bernie.geckolib.renderer.base.GeoRenderState;

import java.util.function.Consumer;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.render.command.OrderedRenderCommandQueue;
import net.minecraft.client.render.item.ItemRenderState;
import net.minecraft.client.render.item.model.special.SpecialModelRenderer;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.client.world.ClientWorld;
import net.minecraft.item.Item;
import net.minecraft.item.ItemDisplayContext;
import net.minecraft.item.ItemStack;
import net.minecraft.util.HeldItemContext;

/**
 * SpecialModelRenderer instance to facilitate rendering GeckoLib items using the vanilla special renderer system
 *
 * @param <T> Item animatable class type
 */
@ApiStatus.Internal
public class GeckolibItemSpecialRenderer<T extends Item & GeoAnimatable> implements SpecialModelRenderer<GeckolibItemSpecialRenderer.RenderData<T>> {
    @Override
    public void submit(GeckolibItemSpecialRenderer.@Nullable RenderData<T> renderData, ItemDisplayContext itemDisplayContext, MatrixStack poseStack, OrderedRenderCommandQueue renderTasks,
                       int packedLight, int packedOverlay, boolean hasGlint, int outlineColor) {
        if (renderData == null)
            return;

        renderData.renderState.addGeckolibData(DataTickets.HAS_GLINT, hasGlint);
        renderData.renderState.addGeckolibData(DataTickets.PACKED_OVERLAY, packedOverlay);
        renderData.renderState.addGeckolibData(DataTickets.PACKED_LIGHT, packedLight);

        renderData.renderer.submit(renderData.renderState, poseStack, renderTasks, outlineColor);
    }

    @Override
    public void collectVertices(Consumer<Vector3fc> consumer) {
        consumer.accept(new Vector3f(0, 0, 0));
    }

    /**
     * Wrap the {@link #getData(ItemStack)} call to provide all the context available, rather than just what Mojang provides
     */
    @SuppressWarnings({"unchecked", "rawtypes"})
    public GeckolibItemSpecialRenderer.@Nullable RenderData<T> extractArgument(ItemStack itemStack, ItemRenderState renderState, ItemDisplayContext context,
                                                                     @Nullable ClientWorld level, @Nullable HeldItemContext itemOwner) {
        T item = makeCovariantItem(itemStack.getItem());

        if (item == null)
            return null;

        GeoItemRenderer<T> renderer = (GeoItemRenderer)GeoRenderProvider.of(item).getGeoItemRenderer();

        if (renderer == null)
            return null;

        return new RenderData<>(item, buildRenderState(item, itemStack, renderer, renderState, context, level, itemOwner), renderer);
    }

    /**
     * Should not be used
     */
    @Deprecated
    @Override
    public GeckolibItemSpecialRenderer.@Nullable RenderData<T> getData(ItemStack itemStack) {
        return extractArgument(itemStack, new ItemRenderState(), ItemDisplayContext.FIXED, null, null);
    }

    @SuppressWarnings("unchecked")
    private @Nullable T makeCovariantItem(Item item) {
        return item instanceof GeoAnimatable ? (T)item : null;
    }

    private GeoRenderState buildRenderState(T animatable, ItemStack itemStack, GeoItemRenderer<T> renderer, ItemRenderState renderState, ItemDisplayContext context,
                                            @Nullable ClientWorld level, @Nullable HeldItemContext itemOwner) {
        final GeoItemRenderer.RenderData renderData = new GeoItemRenderer.RenderData(itemStack, renderState, context, level, itemOwner);

        return renderer.fillRenderState(animatable, renderData, renderer.createRenderState(animatable, renderData),
                                        MinecraftClient.getInstance().getRenderTickCounter().getTickProgress(true));
    }

    public static class Unbaked implements SpecialModelRenderer.Unbaked {
        public static final MapCodec<GeckolibItemSpecialRenderer.Unbaked> MAP_CODEC = MapCodec.unit(software.bernie.geckolib.renderer.internal.GeckolibItemSpecialRenderer.Unbaked::new);

        @Override
        public @Nullable SpecialModelRenderer<?> bake(BakeContext context) {
            return new GeckolibItemSpecialRenderer<>();
        }

        @Override
        public MapCodec<? extends SpecialModelRenderer.Unbaked> getCodec() {
            return MAP_CODEC;
        }
    }

    public record RenderData<T extends Item & GeoAnimatable>(T item, GeoRenderState renderState, GeoItemRenderer<T> renderer) {}
}