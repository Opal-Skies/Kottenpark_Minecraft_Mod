package software.bernie.geckolib.mixin.client;

import com.llamalad7.mixinextras.injector.wrapmethod.WrapMethod;
import com.llamalad7.mixinextras.injector.wrapoperation.Operation;
import net.minecraft.client.render.entity.EntityRenderer;
import net.minecraft.client.render.entity.LivingEntityRenderer;
import net.minecraft.client.render.entity.feature.ArmorFeatureRenderer;
import net.minecraft.client.render.entity.state.BipedEntityRenderState;
import net.minecraft.client.render.entity.state.EntityRenderState;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EquipmentSlot;
import net.minecraft.entity.LivingEntity;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.Constant;
import org.spongepowered.asm.mixin.injection.ModifyConstant;
import software.bernie.geckolib.renderer.GeoArmorRenderer;
import software.bernie.geckolib.renderer.GeoEntityRenderer;
import software.bernie.geckolib.renderer.base.GeoRenderState;

@Mixin(value = EntityRenderer.class, priority = 5000)
public class EntityRendererMixin<T extends Entity, S extends EntityRenderState> {
    /**
     * Override the maximum distance a GeckoLib entity's nameplate can render at, since vanilla caps it at 64 blocks
     */
    @ModifyConstant(method = "extractRenderState", constant = @Constant(doubleValue = 4096.0F), require = 0)
    public double modifyMaxNameplateDistance(double constant) {
        return (Object)this instanceof GeoEntityRenderer<?, ?> ? 256 * 256 : constant;
    }

    /**
     * Injection mixin to allow for capture of data for {@link GeoRenderState}s for {@link GeoArmorRenderer}s,
     * given that they never normally receive the entity context
     */
    @SuppressWarnings({"ConstantValue", "rawtypes", "unchecked"})
    @WrapMethod(method = "createRenderState(Lnet/minecraft/world/entity/Entity;F)Lnet/minecraft/client/renderer/entity/state/EntityRenderState;")
    public S geckolib$captureDataForArmorLayer(T entity, float partialTick, Operation<S> original) {
        S renderState = original.call(entity, partialTick);

        if (renderState instanceof BipedEntityRenderState && (Object)this instanceof LivingEntityRenderer livingRenderer) {
            for (Object layer : livingRenderer.features) {
                if (layer instanceof ArmorFeatureRenderer armorLayer) {
                    GeoArmorRenderer.captureRenderStates(geckolib$castRenderState(renderState), (LivingEntity)entity, partialTick,
                                                         (renderState2, slot) -> armorLayer.getModel(renderState2, slot),
                                                         slot -> geckolib$castRenderState(slot == EquipmentSlot.HEAD ? renderState : original.call(entity, partialTick)));

                    break;
                }
            }
        }

        return renderState;
    }

    /**
     * Sugar method for blind-casting RenderStates to GeckoLib-supported generic types
     */
    @SuppressWarnings("unchecked")
    @Unique
    private static <R extends BipedEntityRenderState & GeoRenderState> R geckolib$castRenderState(EntityRenderState renderState) {
        return (R)renderState;
    }
}
