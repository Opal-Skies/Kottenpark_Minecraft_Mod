package software.bernie.geckolib.mixin.client;

import com.llamalad7.mixinextras.injector.wrapoperation.Operation;
import com.llamalad7.mixinextras.injector.wrapoperation.WrapOperation;
import net.minecraft.client.item.ItemModelManager;
import net.minecraft.client.render.item.ItemRenderState;
import net.minecraft.client.render.item.model.SpecialItemModel;
import net.minecraft.client.render.item.model.special.SpecialModelRenderer;
import net.minecraft.client.world.ClientWorld;
import net.minecraft.item.ItemDisplayContext;
import net.minecraft.item.ItemStack;
import net.minecraft.util.HeldItemContext;
import org.jspecify.annotations.Nullable;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import software.bernie.geckolib.renderer.internal.GeckolibItemSpecialRenderer;

@Mixin(SpecialItemModel.class)
public class SpecialModelWrapperMixin {
    /**
     * Expand the data points available for GeckoLib item rendering, since vanilla ignores most of it
     */
    @SuppressWarnings({"unchecked", "rawtypes"})
    @WrapOperation(method = "update", at = @At(value = "INVOKE", target = "Lnet/minecraft/client/renderer/special/SpecialModelRenderer;extractArgument(Lnet/minecraft/world/item/ItemStack;)Ljava/lang/Object;"))
    public <T> @Nullable T geckolib$extractAllArguments(SpecialModelRenderer<T> instance, ItemStack itemStack, Operation<T> original,
                                              ItemRenderState renderState, ItemStack itemStack2, ItemModelManager modelResolver,
                                              ItemDisplayContext displayContext, @Nullable ClientWorld level, @Nullable HeldItemContext itemOwner, int layerIndex) {
        return instance instanceof GeckolibItemSpecialRenderer geckolibRenderer ?
               (T)geckolibRenderer.extractArgument(itemStack, renderState, displayContext, level, itemOwner) :
               original.call(instance, itemStack);
    }
}
