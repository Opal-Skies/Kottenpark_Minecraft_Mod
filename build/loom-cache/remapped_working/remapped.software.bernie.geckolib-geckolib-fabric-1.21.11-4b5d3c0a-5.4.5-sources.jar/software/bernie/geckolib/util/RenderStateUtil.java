package software.bernie.geckolib.util;

import net.minecraft.client.render.entity.state.ArmedEntityRenderState;
import net.minecraft.client.render.entity.state.BipedEntityRenderState;
import net.minecraft.client.render.entity.state.EntityRenderState;
import net.minecraft.client.render.entity.state.LivingEntityRenderState;
import net.minecraft.client.render.entity.state.PlayerEntityRenderState;
import net.minecraft.client.renderer.entity.state.*;
import software.bernie.geckolib.renderer.base.GeoRenderState;

/**
 * Helper class for RenderState-related functionality.
 * <p>
 * Primarily used for cloning RenderStates
 */
public final class RenderStateUtil {
    /**
     * Create a fully cloned copy of an existing {@link EntityRenderState}.
     */
    public static EntityRenderState cloneEntityState(EntityRenderState existingState) {
        final EntityRenderState newState = new EntityRenderState();

        fullCopyEntityState(newState, existingState);

        return newState;
    }

    /**
     * Fully copy an existing {@link EntityRenderState} to a new one.
     */
    public static void fullCopyEntityState(EntityRenderState newRenderState, EntityRenderState oldRenderState) {
        newRenderState.entityType = oldRenderState.entityType;
        newRenderState.x = oldRenderState.x;
        newRenderState.y = oldRenderState.y;
        newRenderState.z = oldRenderState.z;
        newRenderState.age = oldRenderState.age;
        newRenderState.width = oldRenderState.width;
        newRenderState.height = oldRenderState.height;
        newRenderState.standingEyeHeight = oldRenderState.standingEyeHeight;
        newRenderState.squaredDistanceToCamera = oldRenderState.squaredDistanceToCamera;
        newRenderState.invisible = oldRenderState.invisible;
        newRenderState.sneaking = oldRenderState.sneaking;
        newRenderState.onFire = oldRenderState.onFire;
        newRenderState.light = oldRenderState.light;
        newRenderState.outlineColor = oldRenderState.outlineColor;
        newRenderState.positionOffset = oldRenderState.positionOffset;
        newRenderState.displayName = oldRenderState.displayName;
        newRenderState.nameLabelPos = oldRenderState.nameLabelPos;
        newRenderState.leashDatas = oldRenderState.leashDatas;
        newRenderState.shadowRadius = oldRenderState.shadowRadius;

        newRenderState.shadowPieces.addAll(oldRenderState.shadowPieces);
        ((GeoRenderState)newRenderState).getDataMap().putAll(((GeoRenderState)oldRenderState).getDataMap());
    }

    /**
     * Create a fully cloned copy of an existing {@link LivingEntityRenderState}.
     */
    public static LivingEntityRenderState cloneLivingEntityState(LivingEntityRenderState existingState) {
        final LivingEntityRenderState newState = new LivingEntityRenderState();

        fullCopyLivingEntityState(newState, existingState);

        return newState;
    }

    /**
     * Fully copy an existing {@link LivingEntityRenderState} to a new one.
     */
    public static void fullCopyLivingEntityState(LivingEntityRenderState newRenderState, LivingEntityRenderState oldRenderState) {
        fullCopyEntityState(newRenderState, oldRenderState);

        newRenderState.bodyYaw = oldRenderState.bodyYaw;
        newRenderState.relativeHeadYaw = oldRenderState.relativeHeadYaw;
        newRenderState.pitch = oldRenderState.pitch;
        newRenderState.deathTime = oldRenderState.deathTime;
        newRenderState.limbSwingAnimationProgress = oldRenderState.limbSwingAnimationProgress;
        newRenderState.limbSwingAmplitude = oldRenderState.limbSwingAmplitude;
        newRenderState.baseScale = oldRenderState.baseScale;
        newRenderState.ageScale = oldRenderState.ageScale;
        newRenderState.flipUpsideDown = oldRenderState.flipUpsideDown;
        newRenderState.shaking = oldRenderState.shaking;
        newRenderState.baby = oldRenderState.baby;
        newRenderState.touchingWater = oldRenderState.touchingWater;
        newRenderState.usingRiptide = oldRenderState.usingRiptide;
        newRenderState.hurt = oldRenderState.hurt;
        newRenderState.invisibleToPlayer = oldRenderState.invisibleToPlayer;
        newRenderState.sleepingDirection = oldRenderState.sleepingDirection;
        newRenderState.pose = oldRenderState.pose;
        newRenderState.headItemRenderState = oldRenderState.headItemRenderState;
        newRenderState.headItemAnimationProgress = oldRenderState.headItemAnimationProgress;
        newRenderState.wearingSkullType = oldRenderState.wearingSkullType;
        newRenderState.wearingSkullProfile = oldRenderState.wearingSkullProfile;
    }

    /**
     * Create a fully cloned copy of an existing {@link ArmedEntityRenderState}.
     */
    public static ArmedEntityRenderState cloneArmedEntityState(ArmedEntityRenderState existingState) {
        final ArmedEntityRenderState newState = new ArmedEntityRenderState();

        fullCopyArmedEntityState(newState, existingState);

        return newState;
    }

    /**
     * Fully copy an existing {@link ArmedEntityRenderState} to a new one.
     */
    public static void fullCopyArmedEntityState(ArmedEntityRenderState newRenderState, ArmedEntityRenderState oldRenderState) {
        fullCopyLivingEntityState(newRenderState, oldRenderState);

        newRenderState.mainArm = oldRenderState.mainArm;
        newRenderState.rightArmPose = oldRenderState.rightArmPose;
        newRenderState.rightHandItemState = oldRenderState.rightHandItemState;
        newRenderState.leftArmPose = oldRenderState.leftArmPose;
        newRenderState.leftHandItemState = oldRenderState.leftHandItemState;
    }

    /**
     * Create a fully cloned copy of an existing {@link BipedEntityRenderState}.
     */
    public static BipedEntityRenderState cloneHumanoidEntityState(BipedEntityRenderState existingState) {
        final BipedEntityRenderState newState = new BipedEntityRenderState();

        fullCopyHumanoidEntityState(newState, existingState);

        return newState;
    }

    /**
     * Fully copy an existing {@link BipedEntityRenderState} to a new one.
     */
    public static void fullCopyHumanoidEntityState(BipedEntityRenderState newRenderState, BipedEntityRenderState oldRenderState) {
        fullCopyArmedEntityState(newRenderState, oldRenderState);

        newRenderState.leaningPitch = oldRenderState.leaningPitch;
        newRenderState.handSwingProgress = oldRenderState.handSwingProgress;
        newRenderState.limbAmplitudeInverse = oldRenderState.limbAmplitudeInverse;
        newRenderState.crossbowPullTime = oldRenderState.crossbowPullTime;
        newRenderState.itemUseTime = oldRenderState.itemUseTime;
        newRenderState.preferredArm = oldRenderState.preferredArm;
        newRenderState.activeHand = oldRenderState.activeHand;
        newRenderState.isInSneakingPose = oldRenderState.isInSneakingPose;
        newRenderState.isGliding = oldRenderState.isGliding;
        newRenderState.isSwimming = oldRenderState.isSwimming;
        newRenderState.hasVehicle = oldRenderState.hasVehicle;
        newRenderState.isUsingItem = oldRenderState.isUsingItem;
        newRenderState.leftWingPitch = oldRenderState.leftWingPitch;
        newRenderState.leftWingYaw = oldRenderState.leftWingYaw;
        newRenderState.leftWingRoll = oldRenderState.leftWingRoll;
        newRenderState.equippedHeadStack = oldRenderState.equippedHeadStack;
        newRenderState.equippedChestStack = oldRenderState.equippedChestStack;
        newRenderState.equippedLegsStack = oldRenderState.equippedLegsStack;
        newRenderState.equippedFeetStack = oldRenderState.equippedFeetStack;
    }

    /**
     * Create a fully cloned copy of an existing {@link PlayerEntityRenderState}.
     */
    public static PlayerEntityRenderState cloneAvatarEntityState(PlayerEntityRenderState existingState) {
        final PlayerEntityRenderState newState = new PlayerEntityRenderState();

        fullCopyAvatarEntityState(newState, existingState);

        return newState;
    }

    /**
     * Fully copy an existing {@link PlayerEntityRenderState} to a new one.
     */
    public static void fullCopyAvatarEntityState(PlayerEntityRenderState newRenderState, PlayerEntityRenderState oldRenderState) {
        fullCopyHumanoidEntityState(newRenderState, oldRenderState);

        newRenderState.skinTextures = oldRenderState.skinTextures;
        newRenderState.field_53536 = oldRenderState.field_53536;
        newRenderState.field_53537 = oldRenderState.field_53537;
        newRenderState.field_53538 = oldRenderState.field_53538;
        newRenderState.stuckArrowCount = oldRenderState.stuckArrowCount;
        newRenderState.stingerCount = oldRenderState.stingerCount;
        newRenderState.spectator = oldRenderState.spectator;
        newRenderState.hatVisible = oldRenderState.hatVisible;
        newRenderState.jacketVisible = oldRenderState.jacketVisible;
        newRenderState.leftPantsLegVisible = oldRenderState.leftPantsLegVisible;
        newRenderState.rightPantsLegVisible = oldRenderState.rightPantsLegVisible;
        newRenderState.leftSleeveVisible = oldRenderState.leftSleeveVisible;
        newRenderState.rightSleeveVisible = oldRenderState.rightSleeveVisible;
        newRenderState.capeVisible = oldRenderState.capeVisible;
        newRenderState.glidingTicks = oldRenderState.glidingTicks;
        newRenderState.applyFlyingRotation = oldRenderState.applyFlyingRotation;
        newRenderState.flyingRotation = oldRenderState.flyingRotation;
        newRenderState.playerName = oldRenderState.playerName;
        newRenderState.leftShoulderParrotVariant = oldRenderState.leftShoulderParrotVariant;
        newRenderState.rightShoulderParrotVariant = oldRenderState.rightShoulderParrotVariant;
        newRenderState.id = oldRenderState.id;
        newRenderState.extraEars = oldRenderState.extraEars;
        newRenderState.spyglassState = oldRenderState.spyglassState;
    }

    /**
     * Create a partial-clone of an existing unknown RenderState into a new {@link BipedEntityRenderState} for the purpose of
     * armor rendering, which explicitly requires an {@code HumanoidRenderState}
     * <p>
     * Because this is only being used for armor rendering, we don't need an exhaustive copy of the renderstate and instead focus
     * solely on the data points we know are needed.
     * <p>
     * If you are doing custom modeling and a data point here is missing and causing you issues, let me know in Discord and I'll add it
     */
    public static BipedEntityRenderState makeMinimalArmorRenderingClone(final BipedEntityRenderState newRenderState, final EntityRenderState oldRenderState) {
        ((GeoRenderState)newRenderState).getDataMap().putAll(((GeoRenderState)oldRenderState).getDataMap());

        newRenderState.entityType = oldRenderState.entityType; // Optional
        newRenderState.x = oldRenderState.x; // Optional
        newRenderState.y = oldRenderState.y; // Optional
        newRenderState.z = oldRenderState.z; // Optional
        newRenderState.age = oldRenderState.age;
        newRenderState.standingEyeHeight = oldRenderState.standingEyeHeight; // Optional
        newRenderState.squaredDistanceToCamera = oldRenderState.squaredDistanceToCamera; // Optional
        newRenderState.invisible = oldRenderState.invisible; // Optional
        newRenderState.sneaking = oldRenderState.sneaking; // Optional
        newRenderState.onFire = oldRenderState.onFire; // Optional
        newRenderState.light = oldRenderState.light; // Optional
        newRenderState.outlineColor = oldRenderState.outlineColor; // Optional

        if (oldRenderState instanceof LivingEntityRenderState livingEntityState) {
            newRenderState.bodyYaw = livingEntityState.bodyYaw; // Optional
            newRenderState.relativeHeadYaw = livingEntityState.relativeHeadYaw;
            newRenderState.pitch = livingEntityState.pitch;
            newRenderState.deathTime = livingEntityState.deathTime; // Optional
            newRenderState.limbSwingAnimationProgress = livingEntityState.limbSwingAnimationProgress;
            newRenderState.limbSwingAmplitude = livingEntityState.limbSwingAmplitude;
            newRenderState.baseScale = livingEntityState.baseScale; // Optional
            newRenderState.ageScale = livingEntityState.ageScale;
            newRenderState.flipUpsideDown = livingEntityState.flipUpsideDown; // Optional
            newRenderState.shaking = livingEntityState.shaking; // Optional
            newRenderState.baby = livingEntityState.baby; // Optional
            newRenderState.touchingWater = livingEntityState.touchingWater; // Optional
            newRenderState.usingRiptide = livingEntityState.usingRiptide; // Optional
            newRenderState.hurt = livingEntityState.hurt; // Optional
            newRenderState.invisibleToPlayer = livingEntityState.invisibleToPlayer; // Optional
            newRenderState.sleepingDirection = livingEntityState.sleepingDirection; // Optional
            newRenderState.pose = livingEntityState.pose; // Optional

            if (livingEntityState instanceof ArmedEntityRenderState armedState) {
                newRenderState.mainArm = armedState.mainArm;
                newRenderState.rightArmPose = armedState.rightArmPose;
                newRenderState.leftArmPose = armedState.leftArmPose;

                if (armedState instanceof BipedEntityRenderState humanoidState) {
                    newRenderState.leaningPitch = humanoidState.leaningPitch;
                    newRenderState.handSwingProgress = humanoidState.handSwingProgress;
                    newRenderState.limbAmplitudeInverse = humanoidState.limbAmplitudeInverse;
                    newRenderState.crossbowPullTime = humanoidState.crossbowPullTime;
                    newRenderState.itemUseTime = humanoidState.itemUseTime;
                    newRenderState.preferredArm = humanoidState.preferredArm;
                    newRenderState.activeHand = humanoidState.activeHand;
                    newRenderState.isInSneakingPose = humanoidState.isInSneakingPose;
                    newRenderState.isGliding = humanoidState.isGliding;
                    newRenderState.isSwimming = humanoidState.isSwimming; // Optional
                    newRenderState.hasVehicle = humanoidState.hasVehicle;
                    newRenderState.isUsingItem = humanoidState.isUsingItem;
                    newRenderState.leftWingPitch = humanoidState.leftWingPitch; // Optional
                    newRenderState.leftWingYaw = humanoidState.leftWingYaw; // Optional
                    newRenderState.leftWingRoll = humanoidState.leftWingRoll; // Optional
                    newRenderState.equippedHeadStack = humanoidState.equippedHeadStack; // Optional
                    newRenderState.equippedChestStack = humanoidState.equippedChestStack; // Optional
                    newRenderState.equippedLegsStack = humanoidState.equippedLegsStack; // Optional
                    newRenderState.equippedFeetStack = humanoidState.equippedFeetStack; // Optional
                }
            }
        }

        return newRenderState;
    }

    private RenderStateUtil() {}
}
