package net.kottenpark_mod.entity.custom;

import net.minecraft.class_1296;
import net.minecraft.class_1299;
import net.minecraft.class_1308;
import net.minecraft.class_1341;
import net.minecraft.class_1347;
import net.minecraft.class_1353;
import net.minecraft.class_1361;
import net.minecraft.class_1376;
import net.minecraft.class_1391;
import net.minecraft.class_1394;
import net.minecraft.class_1429;
import net.minecraft.class_1657;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_1856;
import net.minecraft.class_1937;
import net.minecraft.class_3218;
import net.minecraft.class_5132;
import net.minecraft.class_5134;
import net.minecraft.entity.ai.goal.*;
import org.jspecify.annotations.NonNull;
import org.jspecify.annotations.Nullable;
import software.bernie.geckolib.animatable.GeoEntity;
import software.bernie.geckolib.animatable.instance.AnimatableInstanceCache;
import software.bernie.geckolib.animatable.manager.AnimatableManager;
import software.bernie.geckolib.animation.AnimationController;
import software.bernie.geckolib.animation.RawAnimation;
import software.bernie.geckolib.constant.DefaultAnimations;
import software.bernie.geckolib.util.GeckoLibUtil;

public class DuckEntity extends class_1429 implements GeoEntity {
    private final AnimatableInstanceCache geoCache = GeckoLibUtil.createInstanceCache(this);

    public DuckEntity(class_1299<? extends class_1429> entityType, class_1937 world) {
        super(entityType, world);
    }

    @Override
    protected void method_5959() {
        this.field_6201.method_6277(0, new class_1347(this));

        this.field_6201.method_6277(1, new class_1341(this, 1.15D));
        this.field_6201.method_6277(2, new class_1391(this, 1.25D, class_1856.method_8091(class_1802.field_17500), false));

        this.field_6201.method_6277(3, new class_1353(this, 1.1D));

        this.field_6201.method_6277(4, new class_1394(this, 1.0D));
        this.field_6201.method_6277(5, new class_1361(this, class_1657.class, 4.0F));
        this.field_6201.method_6277(6, new class_1376(this));
    }

    public static class_5132.class_5133 createAttributes() {
        return class_1308.method_26828()
                .method_26868(class_5134.field_23716, 18)
                .method_26868(class_5134.field_23719, 0.2)
                .method_26868(class_5134.field_23721, 1)
                .method_26868(class_5134.field_23717, 20)
                .method_26868(class_5134.field_52450, 12);
    }


    @Override
    public boolean method_6481(class_1799 stack) {
        return false;
    }

    @Override
    public @Nullable class_1296 method_5613(class_3218 world, class_1296 entity) {
        return null;
    }


    public static final RawAnimation ANIM_IDLE = RawAnimation.begin().thenPlay("move.stop_walk").thenLoop("misc.idle");
    public static final RawAnimation ANIM_WALK = RawAnimation.begin().thenPlay("move.start_walk").thenLoop("move.walk");
    @Override
    public void registerControllers(AnimatableManager.ControllerRegistrar controllers) {
        controllers.add(new AnimationController<>(test -> {
            if (test.isMoving()) {
                return test.setAndContinue(ANIM_WALK);
            } else {

                return test.setAndContinue(ANIM_IDLE);
            }
        }));
    }

    @Override
    public @NonNull AnimatableInstanceCache getAnimatableInstanceCache() {
        return this.geoCache;
    }
}
