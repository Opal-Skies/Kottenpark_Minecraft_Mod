package net.kottenpark_mod.entity;

import net.kottenpark_mod.KottenparkMod;
import net.kottenpark_mod.entity.custom.ChairEntity;
import net.kottenpark_mod.entity.custom.DuckEntity;
import net.minecraft.class_1299;
import net.minecraft.class_1311;
import net.minecraft.class_2378;
import net.minecraft.class_2960;
import net.minecraft.class_5321;
import net.minecraft.class_7923;
import net.minecraft.class_7924;

public class ModEntities {

    private static final class_5321<class_1299<?>> DUCK_KEY =
            class_5321.method_29179(class_7924.field_41266, class_2960.method_60655(KottenparkMod.MOD_ID, "duck"));
    private static final class_5321<class_1299<?>> CHAIR_KEY =
            class_5321.method_29179(class_7924.field_41266, class_2960.method_60655(KottenparkMod.MOD_ID, "chair"));

    public static final class_1299<DuckEntity> DUCK = class_2378.method_10230(class_7923.field_41177,
            class_2960.method_60655(KottenparkMod.MOD_ID, "duck"),
            class_1299.class_1300.method_5903(DuckEntity::new, class_1311.field_6294)
                    .method_17687(0.5f, 1f).method_5905(DUCK_KEY));


    public static final class_1299<ChairEntity> CHAIR = class_2378.method_10230(class_7923.field_41177,
            class_2960.method_60655(KottenparkMod.MOD_ID, "chair"),
            class_1299.class_1300.method_5903(ChairEntity::new, class_1311.field_17715)
                    .method_17687(0.5f, 0.5f).method_5905(CHAIR_KEY));

    public static void registerModEntities() {
        KottenparkMod.LOGGER.info("Registering Mod Entities for " + KottenparkMod.MOD_ID);
    }
}
