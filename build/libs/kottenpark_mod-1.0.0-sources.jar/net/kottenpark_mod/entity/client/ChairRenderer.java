package net.kottenpark_mod.entity.client;

import net.kottenpark_mod.entity.custom.ChairEntity;
import net.minecraft.class_10017;
import net.minecraft.class_4604;
import net.minecraft.class_5617;
import net.minecraft.class_897;

public class ChairRenderer extends class_897<ChairEntity, class_10017> {

    public ChairRenderer(class_5617.class_5618 context) {
        super(context);
    }

    @Override
    public boolean shouldRender(ChairEntity entity, class_4604 frustum, double x, double y, double z) {
        return true;
    }

    @Override
    public class_10017 method_55269() {
        return new class_10017();
    }
}
