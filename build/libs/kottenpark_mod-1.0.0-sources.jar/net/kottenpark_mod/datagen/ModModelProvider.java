package net.kottenpark_mod.datagen;

import net.fabricmc.fabric.api.client.datagen.v1.provider.FabricModelProvider;
import net.fabricmc.fabric.api.datagen.v1.FabricDataOutput;
import net.kottenpark_mod.block.ModBlocks;
import net.kottenpark_mod.block.custom.TempLampBlock;
import net.kottenpark_mod.item.ModItems;
import net.minecraft.class_2960;
import net.minecraft.class_4910;
import net.minecraft.class_4915;
import net.minecraft.class_4925;
import net.minecraft.class_4926;
import net.minecraft.class_4943;
import net.minecraft.class_4944;
import net.minecraft.class_4946;
import net.minecraft.class_6012;
import net.minecraft.class_807;
import net.minecraft.class_813;
import net.minecraft.client.data.*;

public class ModModelProvider extends FabricModelProvider {

    public ModModelProvider(FabricDataOutput output) {
        super(output);
    }

    @Override
    public void generateBlockStateModels(class_4910 blockStateModelGenerator) {
        blockStateModelGenerator.method_25641(ModBlocks.MAGIC_BLOCK);

        class_4910.class_4912 pinkGarnetPool = blockStateModelGenerator.method_25650(ModBlocks.TEMP_BLOCK);
            pinkGarnetPool.method_25725(ModBlocks.TEMP_STAIRS);
            pinkGarnetPool.method_25724(ModBlocks.TEMP_SLAB);

            pinkGarnetPool.method_25716(ModBlocks.TEMP_BUTTON);
            pinkGarnetPool.method_25723(ModBlocks.TEMP_PRESSURE_PLATE);

            pinkGarnetPool.method_25721(ModBlocks.TEMP_FENCE);
            pinkGarnetPool.method_25722(ModBlocks.TEMP_FENCE_GATE);
            pinkGarnetPool.method_25720(ModBlocks.TEMP_WALL);

        blockStateModelGenerator.method_25658(ModBlocks.TEMP_DOOR);
        blockStateModelGenerator.method_25671(ModBlocks.TEMP_TRAP_DOOR);

        class_2960 lampOffIdentifier = class_4946.field_23036.method_25923(ModBlocks.TEMP_LAMP_BLOCK, blockStateModelGenerator.field_22831);
        class_2960 lampOnIdentifier = blockStateModelGenerator.method_25557(ModBlocks.TEMP_LAMP_BLOCK, "_special", class_4943.field_22972, class_4944::method_25875);
        blockStateModelGenerator.field_22830.accept(class_4925.method_67852(ModBlocks.TEMP_LAMP_BLOCK)
                .method_67859(class_4926.method_67864(TempLampBlock.TEXTURE_STATE)
                        .method_25794(0,new class_807(class_6012.<class_813>method_66215().method_54453(new class_813(lampOffIdentifier)).method_34974()))
                        .method_25794(1,new class_807(class_6012.<class_813>method_66215().method_54453(new class_813(lampOffIdentifier)).method_34974()))
                        .method_25794(2,new class_807(class_6012.<class_813>method_66215().method_54453(new class_813(lampOffIdentifier)).method_34974()))
                        .method_25794(3,new class_807(class_6012.<class_813>method_66215().method_54453(new class_813(lampOffIdentifier)).method_34974()))
                        .method_25794(4,new class_807(class_6012.<class_813>method_66215().method_54453(new class_813(lampOffIdentifier)).method_34974()))
                        .method_25794(5,new class_807(class_6012.<class_813>method_66215().method_54453(new class_813(lampOnIdentifier)).method_34974()))
                ));

        blockStateModelGenerator.method_25708(ModBlocks.CHAIR);
        blockStateModelGenerator.method_25708(ModBlocks.TABLE);
        blockStateModelGenerator.method_25708(ModBlocks.WHITEBOARD);
        blockStateModelGenerator.method_25708(ModBlocks.INFORMATICA_COUCH);
    }

    @Override
    public void generateItemModels(class_4915 itemModelGenerator) {
        itemModelGenerator.method_65442(ModItems.PIG_HEART, class_4943.field_22938);
        itemModelGenerator.method_65442(ModItems.GLIDER_ITEM, class_4943.field_22938);
        itemModelGenerator.method_65442(ModItems.WHITEBOARD_MARKER, class_4943.field_22938);
    }
}
