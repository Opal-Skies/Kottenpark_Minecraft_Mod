package net.kottenpark_mod.datagen;

import net.fabricmc.fabric.api.datagen.v1.FabricDataOutput;
import net.fabricmc.fabric.api.datagen.v1.provider.FabricRecipeProvider;
import net.kottenpark_mod.block.ModBlocks;
import net.kottenpark_mod.item.ModItems;
import net.minecraft.class_1802;
import net.minecraft.class_1935;
import net.minecraft.class_2446;
import net.minecraft.class_7225;
import net.minecraft.class_7800;
import net.minecraft.class_8790;
import java.util.List;
import java.util.concurrent.CompletableFuture;

public class ModRecipeProvider extends FabricRecipeProvider {

    public ModRecipeProvider(FabricDataOutput output, CompletableFuture<class_7225.class_7874> registriesFuture) {
        super(output, registriesFuture);
    }

    @Override
    protected class_2446 method_62766(class_7225.class_7874 wrapperLookup, class_8790 recipeExporter) {
        return new class_2446(wrapperLookup, recipeExporter) {
            @Override
            public void method_10419() {
                List<class_1935> TEMP_SMELTABLES = List.of(ModItems.PIG_HEART);

                method_36233(TEMP_SMELTABLES, class_7800.field_40642, class_1802.field_8094, 0.25f, 200, "temp");
                method_36234(TEMP_SMELTABLES, class_7800.field_40642, class_1802.field_8367, 0.25f, 100, "temp");

                method_36325(class_7800.field_40634, ModItems.PIG_HEART, class_7800.field_40635, ModBlocks.TEMP_BLOCK);

            }
        };
    }

    @Override
    public String method_10321() {
        return "";
    }
}
