package net.kottenpark_mod.datagen;

import net.fabricmc.fabric.api.datagen.v1.FabricDataOutput;
import net.fabricmc.fabric.api.datagen.v1.provider.FabricBlockLootTableProvider;
import net.kottenpark_mod.block.ModBlocks;
import net.kottenpark_mod.item.ModItems;
import net.minecraft.class_141;
import net.minecraft.class_1792;
import net.minecraft.class_1887;
import net.minecraft.class_1893;
import net.minecraft.class_2248;
import net.minecraft.class_52;
import net.minecraft.class_5662;
import net.minecraft.class_7225;
import net.minecraft.class_77;
import net.minecraft.class_7924;
import net.minecraft.class_85;
import net.minecraft.class_94;
import java.util.concurrent.CompletableFuture;

public class ModLootTableProvider extends FabricBlockLootTableProvider {
    public ModLootTableProvider(FabricDataOutput dataOutput, CompletableFuture<class_7225.class_7874> registryLookup) {
        super(dataOutput, registryLookup);
    }

    @Override
    public void method_10379() {

        method_46025(ModBlocks.TEMP_BLOCK);
        method_45988(ModBlocks.MAGIC_BLOCK, multipleOreDrops(ModBlocks.MAGIC_BLOCK, ModItems.PIG_HEART, 1,4));

        method_46025(ModBlocks.TEMP_STAIRS);
        method_45988(ModBlocks.TEMP_SLAB, method_45980(ModBlocks.TEMP_SLAB));

        method_46025(ModBlocks.TEMP_BUTTON);
        method_46025(ModBlocks.TEMP_PRESSURE_PLATE);

        method_46025(ModBlocks.TEMP_WALL);
        method_46025(ModBlocks.TEMP_FENCE);
        method_46025(ModBlocks.TEMP_FENCE_GATE);

        method_45988(ModBlocks.TEMP_DOOR, method_46022(ModBlocks.TEMP_DOOR));
        method_46025(ModBlocks.TEMP_TRAP_DOOR);

    }

    public class_52.class_53 multipleOreDrops(class_2248 drop, class_1792 item, float minDrops, float maxDrops) {
        class_7225.class_7226<class_1887> impl = this.field_51845.method_46762(class_7924.field_41265);
        return this.method_45989(drop, this.method_45977(drop, ((class_85.class_86<?>)
                class_77.method_411(item).method_438(class_141.method_621(class_5662.method_32462(minDrops, maxDrops))))
                .method_438(class_94.method_455(impl.method_46747(class_1893.field_9130)))));
    }
}
