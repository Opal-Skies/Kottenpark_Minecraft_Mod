package net.kottenpark_mod.datagen;

import net.fabricmc.fabric.api.datagen.v1.FabricDataGenerator;
import net.fabricmc.fabric.api.datagen.v1.FabricDataOutput;
import net.fabricmc.fabric.api.datagen.v1.provider.FabricTagProvider;
import net.kottenpark_mod.block.ModBlocks;
import net.minecraft.class_3481;
import net.minecraft.class_7225;
import java.util.concurrent.CompletableFuture;

public class ModBlockTagProvider extends FabricTagProvider.BlockTagProvider {

    public ModBlockTagProvider(FabricDataOutput output, CompletableFuture<class_7225.class_7874> registriesFuture) {
        super(output, registriesFuture);
    }

    @Override
    protected void method_10514(class_7225.class_7874 wrapperLookup) {
        valueLookupBuilder(class_3481.field_33715)
                .method_71554(ModBlocks.TEMP_BLOCK)
                .method_71554(ModBlocks.MAGIC_BLOCK);


        valueLookupBuilder(class_3481.field_16584).method_71554(ModBlocks.TEMP_FENCE);
        valueLookupBuilder(class_3481.field_25147).method_71554(ModBlocks.TEMP_FENCE_GATE);
        valueLookupBuilder(class_3481.field_15504).method_71554(ModBlocks.TEMP_WALL);
    }
}
