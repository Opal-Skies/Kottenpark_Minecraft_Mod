package net.kottenpark_mod.util;

import net.kottenpark_mod.KottenparkMod;
import net.minecraft.class_1792;
import net.minecraft.class_2248;
import net.minecraft.class_2960;
import net.minecraft.class_6862;
import net.minecraft.class_7924;
import javax.swing.text.html.HTML;

public class ModTags {
    public static class Blocks {
        public static class_6862<class_2248> createTag(String name){
            return class_6862.method_40092(class_7924.field_41254, class_2960.method_60655(KottenparkMod.MOD_ID, name));
        };
    };

    public static class Items {

        public static final class_6862<class_1792> TRANSFORMABLE_ITEMS = createTag("transformable_items");
        public static class_6862<class_1792> createTag(String name){
            return class_6862.method_40092(class_7924.field_41197, class_2960.method_60655(KottenparkMod.MOD_ID, name));
        };
    };
}
