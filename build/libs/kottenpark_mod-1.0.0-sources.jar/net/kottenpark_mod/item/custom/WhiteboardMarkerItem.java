package net.kottenpark_mod.item.custom;

import com.ibm.icu.number.Scale;
import net.kottenpark_mod.component.ModDataComponentTypes;
import net.kottenpark_mod.item.ModItems;
import net.minecraft.block.*;
import net.minecraft.class_1268;
import net.minecraft.class_1269;
import net.minecraft.class_1299;
import net.minecraft.class_1309;
import net.minecraft.class_1313;
import net.minecraft.class_1657;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1937;
import net.minecraft.class_2183;
import net.minecraft.class_2246;
import net.minecraft.class_239;
import net.minecraft.class_243;
import net.minecraft.class_2561;
import net.minecraft.class_3218;
import net.minecraft.class_3730;
import net.minecraft.class_3965;
import net.minecraft.class_4050;
import net.minecraft.class_4590;
import net.minecraft.class_8113;
import net.minecraft.class_9290;
import net.minecraft.class_9334;
import net.minecraft.component.type.*;
import net.minecraft.entity.*;
import net.minecraft.item.*;
import net.minecraft.util.math.*;
import org.joml.Vector3f;

import java.lang.reflect.Array;
import java.util.*;
import java.util.function.Consumer;
import java.util.stream.Stream;

public class WhiteboardMarkerItem extends class_1792 {
    class_9290 defaultLore = class_9290.field_49340;
    public WhiteboardMarkerItem(class_1793 settings){
        super(settings
                .method_57349(class_9334.field_49632,class_9290.field_49340.method_57499(class_2561.method_30163("mama mia")))
        );
    }
    private List<String> BoardMarkers = new ArrayList<>();
    private class_243 ClickedCoordinate = new class_243(0,0,0);
    private class_243 PrefClickedCoordinate = new class_243(0,0,0);
    private class_243 CoordinateDifference = new class_243(0,0,0);



    @Override
    public int method_7881(class_1799 stack, class_1309 user) {
        return 72000;
    }

//    @Override
//    public ActionResult use(World world, PlayerEntity user, Hand hand) {
//        user.setCurrentHand(hand);
//        return ActionResult.CONSUME;
//    }

//    @Override
//    public void usageTick(World world, LivingEntity user, ItemStack stack, int remainingUseTicks) {
//        System.out.println("using(tick)");
//        super.usageTick(world, user, stack, remainingUseTicks);
//    }

    @Override
    public class_1269 method_7836(class_1937 world, class_1657 user, class_1268 hand) {
        if(user.method_41328(class_4050.field_18081)){
            user.method_7357().method_62835(this.method_7854(),20);
            if(!world.method_8608()) {
                BoardMarkers.forEach(entityUUID -> {
                    if (world.method_66347(UUID.fromString(entityUUID)) != null) {
                        world.method_66347(UUID.fromString(entityUUID)).method_5768(((class_3218) world));
                    }
                });
            }
        } else {
            class_239 hit = user.method_5745(10,0,false);
            class_243 hitPosition = hit.method_17784();

            if(hit.method_17783() == class_239.class_240.field_1332) {
                ClickedCoordinate = hitPosition;
            }
        }

        user.method_6019(hand);
        return class_1269.field_21466;
    }
    @Override
    public void method_7852(class_1937 world, class_1309 user, class_1799 stack, int remainingUseTicks) {
        if (!world.method_8608() && !((class_1657) user).method_7357().method_7904(stack)) {
            PrefClickedCoordinate = ClickedCoordinate;
            class_239 hit = user.method_5745(4,0,false);
            class_243 hitPosition = hit.method_17784();
            ClickedCoordinate = hitPosition;
            CoordinateDifference = PrefClickedCoordinate.method_1020(ClickedCoordinate);


            if(hit.method_17783() == class_239.class_240.field_1332) {
                class_8113.class_8115 displayEntity = class_1299.field_42460.method_47821(((class_3218) world), ((class_3965) hit).method_17777(), class_3730.field_16465);
                if (displayEntity != null) {
                    BoardMarkers.add(displayEntity.method_5845());

                    displayEntity.method_60949(hitPosition, 0, 0);
                    class_4590 transformation = new class_4590(
                            new Vector3f(-0.05F, -0.05F, -0.05F), null,
                            new Vector3f(0.1F, 0.1F, (float) CoordinateDifference.method_1033()), null);
                    displayEntity.method_48849(transformation);
                    displayEntity.method_5784(class_1313.field_6308, CoordinateDifference.method_1021(0.5));
                    displayEntity.method_5702(class_2183.class_2184.field_9851,PrefClickedCoordinate);

                    displayEntity.method_48883(class_2246.field_10458.method_9564());


                    displayEntity.method_33574(hitPosition);
                }
            }

        } else if (user.method_41328(class_4050.field_18081)){
            ((class_1657) user).method_7357().method_62835(this.method_7854(),20);
        }
    }

    @Override
    public boolean method_7840(class_1799 stack, class_1937 world, class_1309 user, int remainingUseTicks) {
        if(user instanceof class_1657) {
            ((class_1657) user).method_7357().method_62835(stack,20);
        }
        return super.method_7840(stack, world, user, remainingUseTicks);
    }
}
