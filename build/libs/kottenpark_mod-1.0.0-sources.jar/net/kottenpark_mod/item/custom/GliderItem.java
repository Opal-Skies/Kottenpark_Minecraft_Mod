package net.kottenpark_mod.item.custom;

import net.minecraft.class_1268;
import net.minecraft.class_1269;
import net.minecraft.class_1297;
import net.minecraft.class_1304;
import net.minecraft.class_1309;
import net.minecraft.class_1657;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1937;
import net.minecraft.class_243;
import net.minecraft.class_3218;
import org.jspecify.annotations.Nullable;

public class GliderItem extends class_1792 {
    public GliderItem(class_1793 settings){super(settings);}

    private boolean available = true;
    public boolean isAvailable() {
        return available;
    }
    public void setAvailable(boolean available) {
        this.available = available;
    }

    @Override
    public int method_7881(class_1799 stack, class_1309 user) {
        return 80;
    }

    @Override
    public class_1269 method_7836(class_1937 world, class_1657 user, class_1268 hand) {
        if(!user.method_7357().method_7904(this.method_7854())) {
            setAvailable(true);
        };
        if(isAvailable()) {
            setAvailable(false);
            user.method_6019(hand);
            return class_1269.field_21466;
        }
        return class_1269.field_5811;
    }

    @Override
    public void method_7852(class_1937 world, class_1309 user, class_1799 stack, int remainingUseTicks) {
        if (remainingUseTicks >= 0 && !user.method_24828()) {
            class_243 glidingVelocity = new class_243(0.3*Math.cos(user.method_36455()*Math.PI/180)*Math.sin(-user.method_36454()*Math.PI/180),-0.05,0.3* Math.cos(user.method_36455()*Math.PI/180)*Math.cos(-user.method_36454()*Math.PI/180));
            user.method_18799(glidingVelocity);
            user.field_6017 = 0.0f;
        }
    }

    @Override
    public class_1799 method_7861(class_1799 stack, class_1937 world, class_1309 user) {
        ((class_1657) user).method_7357().method_62835(stack,100);
        return super.method_7861(stack, world, user);
    }

    @Override
    public boolean method_7840(class_1799 stack, class_1937 world, class_1309 user, int remainingUseTicks) {
        return super.method_7840(stack, world, user, remainingUseTicks);
    }

    @Override
    public void method_7888(class_1799 stack, class_3218 world, class_1297 entity, @Nullable class_1304 slot) {
        super.method_7888(stack, world, entity, slot);
    }
}
