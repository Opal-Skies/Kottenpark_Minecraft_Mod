package net.kottenpark_mod.item;

import net.fabricmc.fabric.api.itemgroup.v1.ItemGroupEvents;
import net.kottenpark_mod.KottenparkMod;
import net.kottenpark_mod.item.custom.GliderItem;
import net.kottenpark_mod.item.custom.WhiteboardMarkerItem;
import net.minecraft.class_1792;
import net.minecraft.class_2378;
import net.minecraft.class_2960;
import net.minecraft.class_5321;
import net.minecraft.class_7923;
import net.minecraft.class_7924;
import java.util.function.Function;

public class ModItems {

    public static final class_1792 PIG_HEART = registerItem("pig_heart", class_1792::new);

    public static final class_1792 WHITEBOARD_MARKER = registerItem("whiteboard_marker",
            settings -> new WhiteboardMarkerItem(settings.method_7889(1)));

    public static final class_1792 GLIDER_ITEM = registerItem("glider",
            settings -> new GliderItem(settings.method_7889(1)));

    private static class_1792 registerItem(String name, Function<class_1792.class_1793, class_1792> function) {
        return class_2378.method_10230(class_7923.field_41178, class_2960.method_60655(KottenparkMod.MOD_ID, name),
                function.apply(new class_1792.class_1793().method_63686(class_5321.method_29179(class_7924.field_41197, class_2960.method_60655(KottenparkMod.MOD_ID, name)))));
    }

    public static void registerModItems() {
        KottenparkMod.LOGGER.info("registering for" + KottenparkMod.MOD_ID);

    }
}
