package net.kottenpark_mod.item;

import net.fabricmc.fabric.api.itemgroup.v1.FabricItemGroup;
import net.kottenpark_mod.KottenparkMod;
import net.kottenpark_mod.block.ModBlocks;
import net.minecraft.class_1761;
import net.minecraft.class_1799;
import net.minecraft.class_2378;
import net.minecraft.class_2561;
import net.minecraft.class_2960;
import net.minecraft.class_7923;

public class ModItemGroups {

    public static final class_1761 KOTTENPARK_ITEMS_GROUP = class_2378.method_10230(class_7923.field_44687,
            class_2960.method_60655(KottenparkMod.MOD_ID, "kottenpark_item_group"),
            FabricItemGroup.builder().method_47320(() -> new class_1799(ModItems.PIG_HEART))
                    .method_47321(class_2561.method_43471("itemgroup.kottenpark_mod.kottenpark_item_group"))
                    .method_47317((displayContext, entries) -> {
                        entries.method_45421(ModItems.PIG_HEART);
                        entries.method_45421(ModItems.WHITEBOARD_MARKER);
                        entries.method_45421(ModItems.GLIDER_ITEM);

                        entries.method_45421(ModBlocks.CHAIR);
                        entries.method_45421(ModBlocks.TABLE);
                        entries.method_45421(ModBlocks.WHITEBOARD);
                        entries.method_45421(ModBlocks.INFORMATICA_COUCH);
                        entries.method_45421(ModBlocks.MAGIC_BLOCK);
                        entries.method_45421(ModBlocks.TEMP_LAMP_BLOCK);

                        entries.method_45421(ModBlocks.TEMP_BLOCK);
                        entries.method_45421(ModBlocks.TEMP_STAIRS);
                        entries.method_45421(ModBlocks.TEMP_SLAB);

                        entries.method_45421(ModBlocks.TEMP_BUTTON);
                        entries.method_45421(ModBlocks.TEMP_PRESSURE_PLATE);

                        entries.method_45421(ModBlocks.TEMP_FENCE);
                        entries.method_45421(ModBlocks.TEMP_FENCE_GATE);
                        entries.method_45421(ModBlocks.TEMP_WALL);

                        entries.method_45421(ModBlocks.TEMP_DOOR);
                        entries.method_45421(ModBlocks.TEMP_TRAP_DOOR);

                    }).method_47324());

    public static void registerItemGroups() {
        KottenparkMod.LOGGER.info("Registering Item Groups for " + KottenparkMod.MOD_ID);
    }
}
