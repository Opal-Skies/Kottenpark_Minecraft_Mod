package net.kottenpark_mod.sound;

import net.kottenpark_mod.KottenparkMod;
import net.minecraft.class_2378;
import net.minecraft.class_2498;
import net.minecraft.class_2960;
import net.minecraft.class_3414;
import net.minecraft.class_7923;

public class ModSounds {
    public static final class_3414 TEST_BLOCK_BREAK = registerSoundEvent("test_block_break");
    public static final class_3414 TEST_BLOCK_STEP = registerSoundEvent("test_block_step");
    public static final class_3414 TEST_BLOCK_PLACE = registerSoundEvent("test_block_place");
    public static final class_3414 TEST_BLOCK_HIT = registerSoundEvent("test_block_hit");
    public static final class_3414 TEST_BLOCK_FALL = registerSoundEvent("test_block_fall");

    public static final class_2498 TEST_BLOCK_SOUNDS = new class_2498(1.0f,1.0f,
            TEST_BLOCK_BREAK, TEST_BLOCK_STEP, TEST_BLOCK_PLACE, TEST_BLOCK_HIT, TEST_BLOCK_FALL);

    private static class_3414 registerSoundEvent(String name) {
        class_2960 id = class_2960.method_60655(KottenparkMod.MOD_ID, name);
        return class_2378.method_10230(class_7923.field_41172, id, class_3414.method_47908(id));
    };

    public static void registerSounds() {
        KottenparkMod.LOGGER.info("Registering Sounds");
    }
}
