package net.kottenpark_mod.component;

import net.kottenpark_mod.KottenparkMod;
import net.minecraft.class_2378;
import net.minecraft.class_243;
import net.minecraft.class_2960;
import net.minecraft.class_7923;
import net.minecraft.class_9331;
import org.joml.Vector2d;

import java.util.Vector;
import java.util.function.UnaryOperator;

public class ModDataComponentTypes {
    public static final class_9331<class_243> CLICK_COORDINATE = register("coordinates", builder -> builder.method_57881(class_243.field_38277));
    public static final class_9331<class_243> PREF_CLICK_COORDINATE = register("coordinates", builder -> builder.method_57881(class_243.field_38277));


    private static <T>class_9331<T> register(String name, UnaryOperator<class_9331.class_9332<T>> builderOperator) {
        return class_2378.method_10230(class_7923.field_49658, class_2960.method_60655(KottenparkMod.MOD_ID, name),
                builderOperator.apply(new class_9331.class_9332<>()).method_57880());
    }
    public static void registerDataComponentTypes() {
        KottenparkMod.LOGGER.info("Registering data component types.");
    }
}
