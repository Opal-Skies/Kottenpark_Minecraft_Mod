package net.kottenpark_mod.block.custom;

import com.mojang.serialization.MapCodec;
import net.minecraft.block.*;
import net.minecraft.class_1750;
import net.minecraft.class_1922;
import net.minecraft.class_2237;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_2343;
import net.minecraft.class_2350;
import net.minecraft.class_2415;
import net.minecraft.class_2470;
import net.minecraft.class_2586;
import net.minecraft.class_265;
import net.minecraft.class_2680;
import net.minecraft.class_2689;
import net.minecraft.class_2741;
import net.minecraft.class_2754;
import net.minecraft.class_2758;
import net.minecraft.class_3726;
import net.minecraft.class_7718;
import org.jetbrains.annotations.Nullable;

public class WhiteboardBlock extends class_2237 implements class_2343 {

    public static final class_2758 ROTATION = class_2741.field_12532;
    public static final class_2754<class_2350> FACING = class_2741.field_12481;

    private static final class_265 SHAPE = class_2248.method_9541(3, 0, 3, 13, 8, 13);
    public WhiteboardBlock(class_2251 settings) {
        super(settings);
        this.method_9590(this.field_10647.method_11664().method_11657(ROTATION, 0));
    }

    @Override
    protected class_265 method_9530(class_2680 state, class_1922 world, class_2338 pos, class_3726 context) {
        return SHAPE;
    }

    public static final MapCodec<WhiteboardBlock> field_46280 = method_54094(WhiteboardBlock::new);

    @Override
    protected MapCodec<WhiteboardBlock> method_53969() {
        return field_46280;
    }


    @Nullable
    @Override
    public class_2680 method_9605(class_1750 ctx) {
        return this.method_9564()
                .method_11657(ROTATION, class_7718.method_45479(ctx.method_8044() + 180.0F));
    }


    public float getRotationDegrees(class_2680 state) {
        return class_7718.method_45482((Integer)state.method_11654(ROTATION));
    }

    @Override
    protected class_2680 method_9598(class_2680 state, class_2470 rotation) {
        return state.method_11657(ROTATION, rotation.method_10502((Integer)state.method_11654(ROTATION), 16));
    }

    @Override
    protected class_2680 method_9569(class_2680 state, class_2415 mirror) {
        return state.method_11657(ROTATION, mirror.method_10344((Integer)state.method_11654(ROTATION), 16));
    }

    @Override
    protected void method_9515(class_2689.class_2690<class_2248, class_2680> builder) {
        builder.method_11667(ROTATION);
    }

    @Override
    public @org.jspecify.annotations.Nullable class_2586 method_10123(class_2338 pos, class_2680 state) {
        return null;
    }
}
