package net.kottenpark_mod.block.custom;

import net.minecraft.class_1269;
import net.minecraft.class_1657;
import net.minecraft.class_1937;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_2680;
import net.minecraft.class_2689;
import net.minecraft.class_2758;
import net.minecraft.class_3965;

public class TempLampBlock extends class_2248 {
    public static final class_2758 TEXTURE_STATE = class_2758.method_11867("texture_state",0,5);
    public TempLampBlock(class_2251 settings) {
        super(settings);
        method_9590(this.method_9564().method_11657(TEXTURE_STATE,0));
    }

    @Override
    protected class_1269 method_55766(class_2680 state, class_1937 world, class_2338 pos, class_1657 player, class_3965 hit) {
        if(!world.method_8608()){
            world.method_8501(pos, state.method_28493(TEXTURE_STATE));
        }

        return class_1269.field_5812;
    }

    @Override
    protected void method_9515(class_2689.class_2690<class_2248, class_2680> builder) {
        builder.method_11667(TEXTURE_STATE);
    }
}
