package net.kottenpark_mod.block.custom;

import com.mojang.serialization.MapCodec;
import net.minecraft.class_1750;
import net.minecraft.class_1922;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_2383;
import net.minecraft.class_265;
import net.minecraft.class_2680;
import net.minecraft.class_2689;
import net.minecraft.class_3726;
import org.jetbrains.annotations.Nullable;

public class InformaticaCouchBlock extends class_2383 {
    public InformaticaCouchBlock(class_2251 settings) {
        super(settings);
    }
    private static final class_265 SHAPE = class_2248.method_9541(3, 0, 3, 13, 10, 13);

    @Override
    protected class_265 method_9530(class_2680 state, class_1922 world, class_2338 pos, class_3726 context) {
        return SHAPE;
    }

    public static final MapCodec<InformaticaCouchBlock> field_46280 = method_54094(InformaticaCouchBlock::new);

    @Override
    protected MapCodec<? extends class_2383> method_53969() {
        return field_46280;
    }


    @Nullable
    @Override
    public class_2680 method_9605(class_1750 ctx) {
        return this.method_9564().method_11657(field_11177, ctx.method_8042().method_10153());
    }

    @Override
    protected void method_9515(class_2689.class_2690<class_2248, class_2680> builder) {
        builder.method_11667(field_11177);
    }
}
