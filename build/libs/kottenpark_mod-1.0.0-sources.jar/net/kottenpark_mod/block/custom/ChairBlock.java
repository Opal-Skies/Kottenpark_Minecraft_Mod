package net.kottenpark_mod.block.custom;

import com.mojang.serialization.MapCodec;
import net.kottenpark_mod.entity.ModEntities;
import net.kottenpark_mod.entity.custom.ChairEntity;
import net.minecraft.class_1269;
import net.minecraft.class_1297;
import net.minecraft.class_1657;
import net.minecraft.class_1750;
import net.minecraft.class_1922;
import net.minecraft.class_1937;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_238;
import net.minecraft.class_2383;
import net.minecraft.class_265;
import net.minecraft.class_2680;
import net.minecraft.class_2689;
import net.minecraft.class_3218;
import net.minecraft.class_3726;
import net.minecraft.class_3730;
import net.minecraft.class_3965;
import org.jetbrains.annotations.Nullable;

import java.util.List;

public class ChairBlock extends class_2383 {
    public ChairBlock(class_2251 settings) {
        super(settings);
    }
    private static final class_265 SHAPE = class_2248.method_9541(3, 0, 3, 13, 10, 13);


    @Override
    public class_1269 method_55766(class_2680 state, class_1937 world, class_2338 pos, class_1657 player, class_3965 hit) {
        if(!world.method_8608()) {
            class_1297 entity = null;
            List<ChairEntity> entities = world.method_18023(ModEntities.CHAIR, new class_238(pos), chair -> true);
            if(entities.isEmpty()) {
                entity = ModEntities.CHAIR.method_47821((class_3218) world, pos, class_3730.field_16461);
            } else {
                entity = entities.get(0);
            }

            player.method_5804(entity);
        }

        return class_1269.field_5812;
    }

    @Override
    protected class_265 method_9530(class_2680 state, class_1922 world, class_2338 pos, class_3726 context) {
        return SHAPE;
    }



    public static final MapCodec<ChairBlock> field_46280 = method_54094(ChairBlock::new);

    @Override
    protected MapCodec<? extends class_2383> method_53969() {
        return field_46280;
    }


    @Nullable
    @Override
    public class_2680 method_9605(class_1750 ctx) {
        return this.method_9564().method_11657(field_11177, ctx.method_8042().method_10153());
    }

    @Override
    protected void method_9515(class_2689.class_2690<class_2248, class_2680> builder) {
        builder.method_11667(field_11177);
    }
}
