package net.kottenpark_mod.block;

import net.kottenpark_mod.KottenparkMod;
import net.kottenpark_mod.block.custom.*;
import net.kottenpark_mod.sound.ModSounds;
import net.minecraft.block.*;
import net.minecraft.class_1747;
import net.minecraft.class_1792;
import net.minecraft.class_2248;
import net.minecraft.class_2269;
import net.minecraft.class_2323;
import net.minecraft.class_2349;
import net.minecraft.class_2354;
import net.minecraft.class_2378;
import net.minecraft.class_2440;
import net.minecraft.class_2482;
import net.minecraft.class_2498;
import net.minecraft.class_2510;
import net.minecraft.class_2533;
import net.minecraft.class_2544;
import net.minecraft.class_2960;
import net.minecraft.class_4719;
import net.minecraft.class_4970;
import net.minecraft.class_5321;
import net.minecraft.class_7923;
import net.minecraft.class_7924;
import net.minecraft.class_8177;
import java.util.function.Function;

public class ModBlocks {


    public static final class_2248 TEMP_BLOCK = registerBlock("temp_block",
            properties -> new class_2248(properties.method_9632(4f).method_29292()
                    .method_9626(class_2498.field_27197)));

    public static final class_2248 CHAIR = registerBlock("chair",
            properties -> new ChairBlock(properties.method_22488()));

    public static final class_2248 TABLE = registerBlock("table",
            properties -> new TableBlock(properties.method_22488()));
    public static final class_2248 WHITEBOARD = registerBlock("whiteboard",
            properties -> new WhiteboardBlock(properties.method_22488()));
    public static final class_2248 INFORMATICA_COUCH = registerBlock("informatica_couch",
            properties -> new InformaticaCouchBlock(properties.method_22488()));
    public static final class_2248 MAGIC_BLOCK = registerBlock("magic_block",
            properties -> new MagicBlock(properties.method_9632(1f).method_29292().method_9626(ModSounds.TEST_BLOCK_SOUNDS)));

    public static final class_2248 TEMP_LAMP_BLOCK = registerBlock("temp_lamp_block",
            properties -> new TempLampBlock(properties.method_9632(1f).method_29292().method_9626(class_2498.field_11531).method_9631(state -> state.method_11654(TempLampBlock.TEXTURE_STATE)*3)));

    public static final class_2248 TEMP_STAIRS = registerBlock("temp_stairs",
            properties -> new class_2510(ModBlocks.TEMP_BLOCK.method_9564()
                    ,properties.method_9632(2f).method_29292()));
    public static final class_2248 TEMP_SLAB = registerBlock("temp_slab",
            properties -> new class_2482(properties.method_9632(2f).method_29292()));
    public static final class_2248 TEMP_BUTTON = registerBlock("temp_button",
            properties -> new class_2269(class_8177.field_42819, 20, properties.method_9632(2f).method_29292().method_9634()));
    public static final class_2248 TEMP_PRESSURE_PLATE = registerBlock("temp_pressure_plate",
            properties -> new class_2440(class_8177.field_42819, properties.method_9632(2f).method_29292()));
    public static final class_2248 TEMP_FENCE = registerBlock("temp_fence",
            properties -> new class_2354(properties.method_9632(2f).method_29292()));
    public static final class_2248 TEMP_FENCE_GATE = registerBlock("temp_fence_gate",
            properties -> new class_2349(class_4719.field_40350,properties.method_9632(2f).method_29292()));
    public static final class_2248 TEMP_WALL = registerBlock("temp_wall",
            properties -> new class_2544(properties.method_9632(2f).method_29292()));
    public static final class_2248 TEMP_DOOR = registerBlock("temp_door",
            properties -> new class_2323(class_8177.field_42819, properties.method_9632(2f).method_29292().method_22488()));
    public static final class_2248 TEMP_TRAP_DOOR = registerBlock("temp_trap_door",
            properties -> new class_2533(class_8177.field_42819, properties.method_9632(2f).method_29292().method_22488()));


    private static class_2248 registerBlock(String name, Function<class_4970.class_2251, class_2248> function) {
        class_2248 toRegister = function.apply(class_4970.class_2251.method_9637().method_63500(class_5321.method_29179(class_7924.field_41254, class_2960.method_60655(KottenparkMod.MOD_ID, name))));
        registerBlockItem(name, toRegister);
        return class_2378.method_10230(class_7923.field_41175, class_2960.method_60655(KottenparkMod.MOD_ID, name), toRegister);
    }

    private static void registerBlockItem(String name, class_2248 block) {
        class_2378.method_10230(class_7923.field_41178, class_2960.method_60655(KottenparkMod.MOD_ID, name),
                new class_1747(block, new class_1792.class_1793().method_63685()
                        .method_63686(class_5321.method_29179(class_7924.field_41197, class_2960.method_60655(KottenparkMod.MOD_ID, name)))));
    }

    public static void registerModBlocks() {
        KottenparkMod.LOGGER.info("Registering Mod Blocks for " + KottenparkMod.MOD_ID);

    }

}
