package net.kottenpark_mod;

import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.rendering.v1.BlockRenderLayerMap;
import net.fabricmc.fabric.api.client.rendering.v1.EntityRendererRegistry;
import net.kottenpark_mod.block.ModBlocks;
import net.kottenpark_mod.entity.ModEntities;
import net.kottenpark_mod.entity.client.ChairRenderer;
import net.minecraft.class_11515;
import net.minecraft.class_5619;
import software.bernie.geckolib.renderer.GeoEntityRenderer;

public class KottenparkModClient implements ClientModInitializer {
    @Override
    public void onInitializeClient() {
        BlockRenderLayerMap.putBlock(ModBlocks.TEMP_DOOR, class_11515.field_60925);
        BlockRenderLayerMap.putBlock(ModBlocks.TEMP_TRAP_DOOR, class_11515.field_60925);


//        EntityRendererFactories.register();
        class_5619.method_32173(ModEntities.DUCK, context -> new GeoEntityRenderer<>(context, ModEntities.DUCK));
        class_5619.method_32173(ModEntities.CHAIR, ChairRenderer::new);
    }
}
